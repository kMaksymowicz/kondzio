﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ZaliczeniowyProjekt.Migrations
{
    /// <inheritdoc />
    public partial class UpdateTaskItemValidation : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
